#include "chassis.hpp"

void init_chassis () {

	double gains[3] = {0.001, 0, 0.0001};
	int rotsens[3] = {8, 10, 6};
	bool rev[3] = {false, true, true};
	int left[4] = {1};
	int right[4] = {3};

    std::shared_ptr<OdomChassisController> chassis = createChassis(
		gains, 
		gains, 
		gains, 
		rotsens, 
		rev, 
		left, 
		right, 
		AbstractMotor::gearset::blue, 
		0.714, 
		360, 
		imev5BlueTPR, 
		0.2413_m, 
		0.08255_m, 
		0.06985_m, 
		0.09525_m, 
		0.06985_m, 
		0.127_m
	);
}