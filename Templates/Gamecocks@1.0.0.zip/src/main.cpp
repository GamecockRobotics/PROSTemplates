#include "main.h"
#include "auton_selector.hpp"
#include "auton_manager.hpp"
#include "chassis.hpp"

void initialize() {

	init_chassis();

	add_autons({auton1, auton2, skills_auton});

	display_init();

}

void disabled() {}

void competition_initialize() {}

void autonomous() {
	run_auton();
}

void opcontrol() {
	pros::Controller master(pros::E_CONTROLLER_MASTER);

	pros::Motor leftMotor (1, true);
	pros::Motor rightMotor (3);

	pros::Motor_Group leftMotors ({leftMotor});
	pros::Motor_Group rightMotors ({rightMotor});

	while (true) {

		leftMotors.move((master.get_analog(ANALOG_RIGHT_Y))-(master.get_analog(ANALOG_LEFT_X)*-1));
		rightMotors.move((master.get_analog(ANALOG_RIGHT_Y))-(master.get_analog(ANALOG_LEFT_X)));

		if (master.get_digital_new_press(DIGITAL_A)) {
			chassis->turnAngle(90_deg);
		}

		pros::delay(20);
	}
}
