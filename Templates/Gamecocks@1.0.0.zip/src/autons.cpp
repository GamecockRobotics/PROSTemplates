#include "autons.hpp"
#include "main.h"
#include <iostream>

void auton1(){
    printf("Running auto 1");
}

void auton2(){
    printf("Running auto 2");
}

void skills_auton(){
    printf("Running skills auto");
}