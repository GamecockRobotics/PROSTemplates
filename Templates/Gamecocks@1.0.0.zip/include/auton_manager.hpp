#include "okapi/api.hpp"

using namespace okapi;

/**
 * @param distPID <Double[]> PID values for distance PID {kP, kI, Kd}
 * Default {0.001, 0, 0.0001}
 * @param turnPID <Double[]> PID values for turn PID {kP, kI, Kd}
 * Default {0.001, 0, 0.0001}
 * @param anglePID <Double[]> PID values for angle PID {kP, kI, Kd}
 * Default {0.001, 0, 0.0001}
 * @param RotSens <Int[]> Ports of Rotation Sensors for odometry {<left>, <right>, <middle>}
 * @param reversed <Bool[]> Which Rotation Sensors need to be reversed {<left>, <right>, <middle>}
 * @param left <Int[]> Ports of motors on left drivetrain (Negative for reversed)
 * @param right <Int[]> Port of motors on right drivetrain (Negative for reversed)
 * @param gearsetDrive <AbstractMotor::gearset> gearset on drive motors (i.e. AbstractMotor::gearset::blue for blue cartridges)
 * @param TrackTPR <int32_t> Ticks Per Rotation on tracking wheels (Standard is 4096)
 * @param DriveTPR <int32_t> Ticks Per Rotation on drive wheels (Standard is imev5BlueTPR)
 * @param driveTrack <QLength> Distance between the center of the drivetrain wheels
 * @param driveDia <QLength> Diameter of drivetrain wheels
 * @param trackDia <QLength> Diameter of tracking wheels (2.75_in for 2.75" wheels)
 * @param track <QLength> Distance between the center of the forward tracking wheels
 * @param midDia <QLength> Diameter of center tracking wheel (2.75_in for 2.75" wheels)
 * @param midDist <QLength> Distance from the center of rotation to the center of the center tracking wheel (CAN'T BE ZERO)
 * 
 * @return OdomChassisController
*/
std::shared_ptr<OdomChassisController> createChassis (double distPID[3], double turnPID[3], double anglePID[3], int RotSens[3], bool reversed[3], int left[], int right[], AbstractMotor::gearset gearsetDrive, double driveRatio, int32_t TrackTPR, int32_t DriveTPR, QLength driveTrack, QLength driveDia, QLength trackDia, QLength track, QLength midDia, QLength midDist);