#include <functional>
#include "pros/apix.h"

extern int auton_page;
extern std::vector<std::function<void ()>> autons;

extern void add_autons(std::vector<std::function<void ()>> list);
extern void run_auton();
extern lv_res_t update_auton(lv_obj_t * btn);