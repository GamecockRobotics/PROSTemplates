extern void auton1 ();
extern void auton2 ();
extern void skills_auton ();