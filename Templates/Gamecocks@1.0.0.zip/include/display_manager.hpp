#include "pros/apix.h"

extern uint16_t cur_page;

extern lv_obj_t * auto_label;

extern void display_init();